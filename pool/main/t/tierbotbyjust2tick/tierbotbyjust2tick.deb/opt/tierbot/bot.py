import io
import json
import os
from pathlib import Path

import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv
from PIL import Image

load_dotenv()

TOKEN = os.getenv("DISCORD_TOKEN")
GUILD_ID = os.getenv("GUILD_ID")

if not TOKEN:
    raise RuntimeError("DISCORD_TOKEN is missing from .env")

if not GUILD_ID:
    raise RuntimeError("GUILD_ID is missing from .env")

BASE_DIR = Path("/root/tierbot")
SKINS_DIR = BASE_DIR / "skins"
RESULTS_DIR = BASE_DIR / "results"
QUEUE_FILE = BASE_DIR / "queue.json"
PANEL_FILE = BASE_DIR / "reghere_panel.json"

SKINS_DIR.mkdir(parents=True, exist_ok=True)
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(
    command_prefix="!",
    intents=intents
)

TIERS = [
    "Unranked",
    "LT5",
    "HT5",
    "LT4",
    "HT4",
    "LT3",
    "HT3",
    "LT2",
    "HT2",
    "LT1",
    "HT1",
    "MT5",
    "MT4",
    "MT3",
    "MT2",
    "MT1"
]

REGIONS = [
    "NA",
    "EU",
    "AS",
    "SA",
    "OCE",
    "MEA"
]

QUEUE_CONFIG = {
    "axe": ("axe-waitlist", "axe-waitlist"),
    "sword": ("sword-waitlist", "sword-waitlist"),
    "vanilla": ("vanilla-waitlist", "vanilla-waitlist"),
    "smp": ("smp-waitlist", "smp-waitlist"),
    "pot": ("pot-waitlist", "pot-waitlist"),
    "mace": ("mace-waitlist", "mace-waitlist"),
    "nethop": ("nethop-waitlist", "nethop-waitlist"),
    "uhc": ("uhc-waitlist", "uhc-waitlist"),
    "spear": ("spear-waitlist", "spear-waitlist"),
}


def clean_username(username: str) -> str:
    username = username.strip()
    return "".join(
        c for c in username
        if c.isalnum() or c in ("_", "-")
    )


def has_role(member: discord.Member, role_name: str) -> bool:
    return discord.utils.get(
        member.roles,
        name=role_name
    ) is not None


def can_give_result(member: discord.Member) -> bool:
    if member.guild_permissions.administrator:
        return True

    return has_role(member, "TESTER TEAM")


def create_face(skin_data: bytes) -> Image.Image:
    skin = Image.open(
        io.BytesIO(skin_data)
    ).convert("RGBA")

    width, height = skin.size

    if width != height:
        raise ValueError("Skin must be square.")

    if width not in (64, 128):
        raise ValueError(
            "Skin must be 64x64 or 128x128."
        )

    scale = width // 64

    base_face = skin.crop(
        (
            8 * scale,
            8 * scale,
            16 * scale,
            16 * scale
        )
    )

    overlay_face = skin.crop(
        (
            40 * scale,
            8 * scale,
            48 * scale,
            16 * scale
        )
    )

    face = Image.alpha_composite(
        base_face,
        overlay_face
    )

    face = face.resize(
        (256, 256),
        Image.Resampling.NEAREST
    )

    return face


def load_queue():
    if not QUEUE_FILE.exists():
        return {}

    try:
        with open(
            QUEUE_FILE,
            "r",
            encoding="utf-8"
        ) as f:
            return json.load(f)
    except Exception:
        return {}


def save_queue(queue):
    with open(
        QUEUE_FILE,
        "w",
        encoding="utf-8"
    ) as f:
        json.dump(queue, f, indent=2)


def get_queue(gamemode):
    queue = load_queue()
    queue.setdefault(gamemode, [])
    save_queue(queue)
    return queue[gamemode]


def set_active_tester(gamemode, user_id):
    queue = load_queue()
    queue.setdefault(gamemode, [])
    queue[gamemode + "_active_tester"] = str(user_id)
    save_queue(queue)


def get_active_tester(gamemode):
    queue = load_queue()
    return queue.get(gamemode + "_active_tester")


async def remove_player_from_queue(guild, user_id, gamemode=None):
    queue = load_queue()

    # If gamemode is valid, check that queue first.
    # Otherwise search every queue.
    if gamemode in QUEUE_CONFIG:
        modes = [gamemode]
    else:
        modes = list(QUEUE_CONFIG.keys())

    removed_mode = None
    next_player = None

    for mode in modes:
        entries = queue.get(mode, [])

        if not isinstance(entries, list):
            continue

        old_queue = list(entries)

        new_queue = [
            entry
            for entry in old_queue
            if str(entry.get("user_id")) != str(user_id)
        ]

        if len(new_queue) != len(old_queue):
            queue[mode] = new_queue
            removed_mode = mode

            if new_queue:
                next_player = new_queue[0]

            break

    # Nothing found.
    if removed_mode is None:
        return None

    save_queue(queue)

    # Remove the player's waitlist role.
    try:
        role_name, channel_name = QUEUE_CONFIG[removed_mode]

        member = guild.get_member(int(user_id))

        if member is None:
            member = await guild.fetch_member(int(user_id))

        role = discord.utils.get(
            guild.roles,
            name=role_name
        )

        if role and role in member.roles:
            await member.remove_roles(
                role,
                reason=f"Completed {removed_mode.title()} tier test"
            )

    except (
        discord.NotFound,
        discord.Forbidden,
        discord.HTTPException,
        ValueError,
        TypeError
    ):
        pass

    # DM the new #1 only.
    if next_player:
        try:
            next_user = guild.get_member(
                int(next_player["user_id"])
            )

            if next_user is None:
                next_user = await guild.fetch_member(
                    int(next_player["user_id"])
                )

            await next_user.send(
                f"🧪 You're **#1** in the "
                f"**{removed_mode.title()} tier-test queue!**"
            )

        except (
            discord.NotFound,
            discord.Forbidden,
            discord.HTTPException,
            ValueError,
            TypeError
        ):
            pass

    # Update the actual Discord queue panel.
    try:
        _, channel_name = QUEUE_CONFIG[removed_mode]

        channel = discord.utils.get(
            guild.text_channels,
            name=channel_name
        )

        if channel is not None:
            async for message in channel.history(limit=100):
                if message.author.id != bot.user.id:
                    continue

                if not message.embeds:
                    continue

                title = message.embeds[0].title or ""

                if title == f"📌 {removed_mode.title()} Queue Is Now Open":
                    await message.edit(
                        embed=await build_queue_embed(
                            guild,
                            removed_mode
                        ),
                        view=QueuePanelView(removed_mode)
                    )
                    break

    except (
        discord.NotFound,
        discord.Forbidden,
        discord.HTTPException
    ):
        pass

    return removed_mode


async def find_user_queue(user_id):
    queue = load_queue()

    for mode, entries in queue.items():
        if not isinstance(entries, list):
            continue

        for entry in entries:
            if str(entry.get("user_id")) == str(user_id):
                return mode

    return None


def get_registration(user_id):
    registration_file = BASE_DIR / "registrations.txt"

    if not registration_file.exists():
        return None

    with open(
        registration_file,
        "r",
        encoding="utf-8"
    ) as f:
        for line in f:
            parts = line.rstrip("\n").split("|")

            if len(parts) >= 3 and parts[0] == str(user_id):
                return parts

    return None


async def build_queue_embed(guild, gamemode):
    queue = load_queue().get(gamemode, [])

    mode_name = gamemode.title()

    if queue:
        queue_lines = []

        for index, entry in enumerate(queue, start=1):
            user_id = str(entry.get("user_id"))
            username = entry.get("username", "Unknown")

            try:
                member = guild.get_member(int(user_id))

                if member is None:
                    member = await guild.fetch_member(int(user_id))

                mention = member.mention

            except (
                ValueError,
                TypeError,
                discord.NotFound,
                discord.HTTPException
            ):
                mention = f"<@{user_id}>"

            queue_lines.append(
                f"`#{index}` {mention} (`{username}`)"
            )

        queue_text = "\n".join(queue_lines)

    else:
        queue_text = "*No one in queue yet*"

    active_tester_id = get_active_tester(gamemode)
    active_tester = None

    if active_tester_id:
        try:
            active_tester = guild.get_member(int(active_tester_id))

            if active_tester is None:
                active_tester = await guild.fetch_member(
                    int(active_tester_id)
                )

        except (
            ValueError,
            TypeError,
            discord.NotFound,
            discord.HTTPException
        ):
            active_tester = None

    if active_tester is not None:
        tester_text = active_tester.mention
    else:
        tester_text = "*No active tester*"

    embed = discord.Embed(
        title=f"📌 {mode_name} Queue Is Now Open",
        description=(
            f"**{mode_name} Queue is Online**\n\n"
            "👤 **Available Tester**\n"
            f"{tester_text}\n\n"
            "📋 **Queue**\n"
            f"{queue_text}"
        ),
        color=discord.Color.green()
    )

    embed.set_footer(
        text=f"{len(queue)} player(s) waiting"
    )

    return embed


class RegisterModal(
    discord.ui.Modal,
    title="Tier Test Registration"
):

    username = discord.ui.TextInput(
        label="In-Game Username",
        placeholder="Example: MC_Vidz",
        required=True,
        max_length=16
    )

    region = discord.ui.TextInput(
        label="Region",
        placeholder="AS / EU / NA / SA / OCE / MEA",
        required=True,
        max_length=3
    )

    async def on_submit(
        self,
        interaction: discord.Interaction
    ):
        if get_registration(
            interaction.user.id
        ) is not None:
            await interaction.response.send_message(
                "❌ **You are already registered.**\n\n"
                "Each Discord account can only register once.",
                ephemeral=True
            )
            return

        username = str(self.username).strip()
        region = str(self.region).strip().upper()

        allowed_regions = {
            "AS",
            "EU",
            "NA",
            "SA",
            "OCE",
            "MEA"
        }

        if region not in allowed_regions:
            await interaction.response.send_message(
                "❌ Invalid region.\n\n"
                "Use one of: `AS`, `EU`, `NA`, `SA`, `OCE`, `MEA`.",
                ephemeral=True
            )
            return

        safe_username = clean_username(username)

        if not safe_username or safe_username != username:
            await interaction.response.send_message(
                "❌ Invalid Minecraft username.\n\n"
                "Use only letters, numbers, `_` or `-`.",
                ephemeral=True
            )
            return

        registration_file = (
            BASE_DIR / "registrations.txt"
        )

        existing = []

        if registration_file.exists():
            with open(
                registration_file,
                "r",
                encoding="utf-8"
            ) as f:
                for line in f:
                    line = line.rstrip("\n")
                    parts = line.split("|")

                    if (
                        len(parts) >= 3
                        and parts[0]
                        != str(interaction.user.id)
                    ):
                        existing.append(line)

        with open(
            registration_file,
            "w",
            encoding="utf-8"
        ) as f:
            for line in existing:
                f.write(line + "\n")

            f.write(
                f"{interaction.user.id}|"
                f"{username}|"
                f"{region}\n"
            )

        await interaction.response.send_message(
            "✅ **Registration Complete!**\n\n"
            f"**In-Game Username:** `{username}`\n"
            f"**Region:** `{region}`\n\n"
            "Your profile is now registered.",
            ephemeral=True
        )


class TestRequestModal(
    discord.ui.Modal,
    title="Request Tier Test"
):

    gamemode = discord.ui.TextInput(
        label="Gamemode",
        placeholder="Example: Sword",
        required=True,
        max_length=30
    )

    async def on_submit(
        self,
        interaction: discord.Interaction
    ):
        if interaction.guild is None:
            await interaction.response.send_message(
                "❌ This can only be used inside a server.",
                ephemeral=True
            )
            return

        registration = get_registration(
            interaction.user.id
        )

        if registration is None:
            await interaction.response.send_message(
                "❌ **You are not registered yet.**\n\n"
                "Please click **Register / Update** first.",
                ephemeral=True
            )
            return

        _, username, region = registration

        mode = self.gamemode.value.strip().lower()

        if mode not in QUEUE_CONFIG:
            await interaction.response.send_message(
                "❌ **Invalid gamemode.**\n\n"
                "Available: "
                + ", ".join(
                    name.title()
                    for name in QUEUE_CONFIG
                ),
                ephemeral=True
            )
            return

        role_name, _ = QUEUE_CONFIG[mode]

        role = discord.utils.get(
            interaction.guild.roles,
            name=role_name
        )

        if role is None:
            await interaction.response.send_message(
                f"❌ The role `{role_name}` does not exist.",
                ephemeral=True
            )
            return

        if role in interaction.user.roles:
            await interaction.response.send_message(
                f"⚠️ You already have the {role.mention} role.",
                ephemeral=True
            )
            return

        try:
            await interaction.user.add_roles(
                role,
                reason=f"Requested {mode.title()} tier test"
            )
        except discord.Forbidden:
            await interaction.response.send_message(
                "❌ I don't have permission to give you that role.",
                ephemeral=True
            )
            return

        await interaction.response.send_message(
            "✅ **Tier Test Request Submitted!**\n\n"
            f"**In-Game Username:** `{username}`\n"
            f"**Region:** `{region}`\n"
            f"**Gamemode:** `{mode.title()}`\n"
            f"**Role:** {role.mention}",
            ephemeral=True
        )


class RegisterPanelView(discord.ui.View):

    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(
        label="Register / Update",
        style=discord.ButtonStyle.success,
        emoji="📝",
        custom_id="tierbot_register"
    )
    async def register_button(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button
    ):
        if get_registration(
            interaction.user.id
        ) is not None:
            await interaction.response.send_message(
                "❌ **You are already registered.**\n\n"
                "Each Discord account can only register once.",
                ephemeral=True
            )
            return

        await interaction.response.send_modal(
            RegisterModal()
        )

    @discord.ui.button(
        label="Upload / Change Skin",
        style=discord.ButtonStyle.secondary,
        emoji="🖼️",
        custom_id="tierbot_skin"
    )
    async def skin_button(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button
    ):
        if get_registration(
            interaction.user.id
        ) is None:
            await interaction.response.send_message(
                "❌ **You are not registered yet.**\n\n"
                "Please click **Register / Update** first.",
                ephemeral=True
            )
            return

        await interaction.response.send_message(
            "📸 Use `/skinupload` and attach your Minecraft skin PNG.",
            ephemeral=True
        )

    @discord.ui.button(
        label="Request Test",
        style=discord.ButtonStyle.primary,
        emoji="⚡",
        custom_id="tierbot_request_test"
    )
    async def request_test_button(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button
    ):
        if get_registration(
            interaction.user.id
        ) is None:
            await interaction.response.send_message(
                "❌ **You are not registered yet.**\n\n"
                "Please click **Register / Update** first.",
                ephemeral=True
            )
            return

        await interaction.response.send_modal(
            TestRequestModal()
        )



@bot.tree.command(
    name="skinupload",
    description="Upload or change your Minecraft skin."
)
@app_commands.describe(
    skin="Your Minecraft skin PNG file."
)
async def skinupload(
    interaction: discord.Interaction,
    skin: discord.Attachment
):
    registration = get_registration(
        interaction.user.id
    )

    if registration is None:
        await interaction.response.send_message(
            "❌ **You are not registered yet.**\n\n"
            "Please use **Register / Update** first.",
            ephemeral=True
        )
        return

    _, username, region = registration

    filename = skin.filename.lower()

    if not filename.endswith(".png"):
        await interaction.response.send_message(
            "❌ **Invalid file.**\n\n"
            "Please upload your Minecraft skin as a `.png` file.",
            ephemeral=True
        )
        return

    try:
        skin_data = await skin.read()

        create_face(skin_data)

        skin_path = (
            SKINS_DIR /
            f"{clean_username(username)}.png"
        )

        with open(
            skin_path,
            "wb"
        ) as f:
            f.write(skin_data)

    except Exception as error:
        await interaction.response.send_message(
            "❌ **Invalid Minecraft skin.**\n\n"
            "The skin must be a valid **64x64 or 128x128 PNG**.",
            ephemeral=True
        )

        print(
            f"Skin upload failed | "
            f"User: {interaction.user} | "
            f"Error: {error}"
        )
        return

    await interaction.response.send_message(
        "✅ **Skin uploaded successfully!**\n\n"
        f"**Minecraft Username:** `{username}`\n"
        f"**Region:** `{region}`\n\n"
        "Your previous skin has been replaced with this new skin successfully!",
        ephemeral=True
    )



@bot.tree.command(
    name="reghere",
    description="Send the public tier test registration panel."
)
async def reghere(
    interaction: discord.Interaction
):
    if not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message(
            "❌ You don't have permission to use this command.",
            ephemeral=True
        )
        return

    embed = discord.Embed(
        title="⚔️ Tier Test Registration",
        description=(
            "Welcome to the tier testing system!\n\n"
            "Register your Minecraft profile, upload your skin, "
            "and request a tier test using the buttons below.\n\n"
            "⚠️ **Minecraft username is case-sensitive.**"
        ),
        color=discord.Color.blurple()
    )

    embed.add_field(
        name="📝 Register / Update",
        value="Register your Minecraft username and region.",
        inline=False
    )

    embed.add_field(
        name="🖼️ Upload / Change Skin",
        value="Upload or replace your Minecraft skin.",
        inline=False
    )

    embed.add_field(
        name="⚡ Request Test",
        value="Request a tier test after registering.",
        inline=False
    )

    await interaction.response.send_message(
        embed=embed,
        view=RegisterPanelView()
    )

    panel_message = await interaction.original_response()

    with open(
        PANEL_FILE,
        "w",
        encoding="utf-8"
    ) as f:
        json.dump(
            {
                "channel_id": interaction.channel.id,
                "message_id": panel_message.id
            },
            f,
            indent=2
        )


class QueuePanelView(discord.ui.View):

    def __init__(self, gamemode):
        super().__init__(timeout=None)
        self.gamemode = gamemode

    @discord.ui.button(
        label="Join",
        style=discord.ButtonStyle.success,
        emoji="✅",
        custom_id="tierbot_queue_join"
    )
    async def join_button(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button
    ):
        if interaction.guild is None:
            await interaction.response.send_message(
                "❌ This can only be used inside a server.",
                ephemeral=True
            )
            return

        registration = get_registration(
            interaction.user.id
        )

        if registration is None:
            await interaction.response.send_message(
                "❌ **You are not registered yet.**\n\n"
                "Use the **Register / Update** button first.",
                ephemeral=True
            )
            return

        _, username, region = registration

        role_name, _ = QUEUE_CONFIG[self.gamemode]

        role = discord.utils.get(
            interaction.guild.roles,
            name=role_name
        )

        if role is None:
            await interaction.response.send_message(
                f"❌ Queue role `{role_name}` was not found.",
                ephemeral=True
            )
            return

        # -------------------------------------------------
        # Prevent joining multiple gamemode queues
        # -------------------------------------------------

        existing_mode = await find_user_queue(
            interaction.user.id
        )

        if existing_mode is not None:
            if existing_mode == self.gamemode:
                await interaction.response.send_message(
                    "⚠️ **You're already in this queue!**",
                    ephemeral=True
                )
            else:
                await interaction.response.send_message(
                    f"⚠️ You're already in the "
                    f"**{existing_mode.title()} queue!** "
                    "Leave it first.",
                    ephemeral=True
                )
            return

        queue = load_queue()
        queue.setdefault(self.gamemode, [])

        # Save whether this queue was empty BEFORE joining.
        was_empty = len(queue[self.gamemode]) == 0

        user_id = str(interaction.user.id)

        queue[self.gamemode].append({
            "user_id": user_id,
            "username": username,
            "region": region
        })

        save_queue(queue)

        if role not in interaction.user.roles:
            try:
                await interaction.user.add_roles(
                    role,
                    reason=f"Joined {self.gamemode.title()} queue"
                )
            except discord.Forbidden:
                pass

        position = len(queue[self.gamemode])

        await interaction.response.send_message(
            f"✅ **You joined the {self.gamemode.title()} queue!**\n\n"
            f"**Position:** `#{position}`\n"
            f"**Username:** `{username}`\n"
            f"**Region:** `{region}`",
            ephemeral=True
        )

        # -------------------------------------------------
        # DM ONLY the person who becomes #1
        # -------------------------------------------------

        if was_empty:
            try:
                await interaction.user.send(
                    f"🧪 You're **#1** in the "
                    f"**{self.gamemode.title()} tier-test queue!**"
                )
            except (
                discord.Forbidden,
                discord.HTTPException
            ):
                pass

        await interaction.message.edit(
            embed=await build_queue_embed(
                interaction.guild,
                self.gamemode
            ),
            view=self
        )

    @discord.ui.button(
        label="Leave",
        style=discord.ButtonStyle.danger,
        emoji="❌",
        custom_id="tierbot_queue_leave"
    )
    async def leave_button(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button
    ):
        if interaction.guild is None:
            await interaction.response.send_message(
                "❌ This can only be used inside a server.",
                ephemeral=True
            )
            return

        role_name, _ = QUEUE_CONFIG[self.gamemode]

        queue = load_queue()
        queue.setdefault(self.gamemode, [])

        user_id = str(interaction.user.id)

        old_length = len(
            queue[self.gamemode]
        )

        queue[self.gamemode] = [
            entry
            for entry in queue[self.gamemode]
            if str(entry.get("user_id")) != user_id
        ]

        if len(queue[self.gamemode]) == old_length:
            await interaction.response.send_message(
                "⚠️ **You're not in this queue.**",
                ephemeral=True
            )
            return

        save_queue(queue)

        role = discord.utils.get(
            interaction.guild.roles,
            name=role_name
        )

        if role and role in interaction.user.roles:
            try:
                await interaction.user.remove_roles(
                    role,
                    reason=f"Left {self.gamemode.title()} queue"
                )
            except discord.Forbidden:
                pass

        await interaction.response.send_message(
            f"👋 **You left the {self.gamemode.title()} queue.**",
            ephemeral=True
        )

        await interaction.message.edit(
            embed=await build_queue_embed(
                interaction.guild,
                self.gamemode
            ),
            view=self
        )



@bot.tree.command(
    name="openqueue",
    description="Open a public tier test queue."
)
@app_commands.describe(
    gamemode="Gamemode queue to open."
)
@app_commands.choices(
    gamemode=[
        app_commands.Choice(
            name="Axe",
            value="axe"
        ),
        app_commands.Choice(
            name="Sword",
            value="sword"
        ),
        app_commands.Choice(
            name="Vanilla",
            value="vanilla"
        ),
        app_commands.Choice(
            name="SMP",
            value="smp"
        ),
        app_commands.Choice(
            name="Pot",
            value="pot"
        ),
        app_commands.Choice(
            name="Mace",
            value="mace"
        ),
        app_commands.Choice(
            name="Nethop",
            value="nethop"
        ),
        app_commands.Choice(
            name="UHC",
            value="uhc"
        ),
        app_commands.Choice(
            name="Spear",
            value="spear"
        )
    ]
)
async def openqueue(
    interaction: discord.Interaction,
    gamemode: app_commands.Choice[str]
):
    if interaction.guild is None:
        await interaction.response.send_message(
            "❌ This can only be used inside a server.",
            ephemeral=True
        )
        return

    if not interaction.user.guild_permissions.manage_messages:
        await interaction.response.send_message(
            "❌ You don't have permission to open test queues.",
            ephemeral=True
        )
        return

    mode = gamemode.value

    _, channel_name = QUEUE_CONFIG[mode]

    channel = discord.utils.get(
        interaction.guild.text_channels,
        name=channel_name
    )

    if channel is None:
        await interaction.response.send_message(
            f"❌ Channel `#{channel_name}` was not found.",
            ephemeral=True
        )
        return

    # The person opening the queue becomes the active tester.
    set_active_tester(mode, interaction.user.id)

    embed = await build_queue_embed(
        interaction.guild,
        mode
    )

    await channel.send(
        content="@here",
        embed=embed,
        view=QueuePanelView(mode),
        allowed_mentions=discord.AllowedMentions(everyone=True)
    )

    await interaction.response.send_message(
        f"✅ **{mode.title()} queue opened!**\n"
        f"Posted in {channel.mention}.",
        ephemeral=True
    )


for _queue_mode in QUEUE_CONFIG:
    bot.add_view(
        QueuePanelView(_queue_mode)
    )

bot.add_view(
    RegisterPanelView()
)



@bot.tree.command(
    name="giveresult",
    description="Give a player their tier test result."
)
@app_commands.describe(
    player="The Discord user who was tested.",
    region="The player's region.",
    username="The player's Minecraft username.",
    gamemode="The gamemode tested.",
    previous_tier="The player's previous tier.",
    new_tier="The player's new tier."
)
@app_commands.choices(
    region=[
        app_commands.Choice(
            name=region,
            value=region
        )
        for region in REGIONS
    ],
    previous_tier=[
        app_commands.Choice(
            name=tier,
            value=tier
        )
        for tier in TIERS
    ],
    new_tier=[
        app_commands.Choice(
            name=tier,
            value=tier
        )
        for tier in TIERS
    ]
)
async def giveresult(
    interaction: discord.Interaction,
    player: discord.Member,
    region: app_commands.Choice[str],
    username: str,
    gamemode: str,
    previous_tier: app_commands.Choice[str],
    new_tier: app_commands.Choice[str]
):
    if not can_give_result(interaction.user):
        await interaction.response.send_message(
            "❌ You don't have permission to use this command.",
            ephemeral=True
        )
        return

    safe_username = clean_username(username)

    skin_path = (
        SKINS_DIR /
        f"{safe_username}.png"
    )

    image_found = skin_path.is_file()

    tier = new_tier.value.upper()

    if "5" in tier:
        embed_color = discord.Color.from_rgb(
            140, 255, 0
        )
    elif "4" in tier:
        embed_color = discord.Color.from_rgb(
            255, 230, 0
        )
    elif "3" in tier:
        embed_color = discord.Color.from_rgb(
            255, 255, 255
        )
    elif "2" in tier:
        embed_color = discord.Color.from_rgb(
            255, 180, 0
        )
    elif "1" in tier:
        embed_color = discord.Color.from_rgb(
            70, 140, 255
        )
    else:
        embed_color = discord.Color.blurple()

    embed = discord.Embed(
        title=f"🏆 Tier Test Result — {username}",
        color=embed_color
    )

    embed.add_field(
        name="Tester",
        value=interaction.user.display_name,
        inline=False
    )

    embed.add_field(
        name="Region",
        value=region.value,
        inline=False
    )

    embed.add_field(
        name="Username",
        value=username,
        inline=False
    )

    embed.add_field(
        name="Gamemode",
        value=gamemode,
        inline=False
    )

    embed.add_field(
        name="Previous Tier",
        value=previous_tier.value,
        inline=False
    )

    embed.add_field(
        name="New Tier",
        value=new_tier.value,
        inline=False
    )

    if image_found:
        embed.add_field(
            name="Player Face",
            value="✅ User image found",
            inline=False
        )

        embed.set_thumbnail(
            url="attachment://player-face.png"
        )

        with open(
            skin_path,
            "rb"
        ) as face_file:
            face_image = create_face(
                face_file.read()
            )

        face_buffer = io.BytesIO()

        face_image.save(
            face_buffer,
            format="PNG"
        )

        face_buffer.seek(0)

        discord_file = discord.File(
            face_buffer,
            filename="player-face.png"
        )

        await interaction.response.send_message(
            content=player.mention,
            embed=embed,
            file=discord_file
        )

    else:
        embed.add_field(
            name="Player Face",
            value="❌ Error - user image not found",
            inline=False
        )

        await interaction.response.send_message(
            content=player.mention,
            embed=embed
        )

    # -----------------------------------------------------
    # Finish the player's queue position.
    # Remove them and DM the new #1 automatically.
    # -----------------------------------------------------

    removed_mode = await remove_player_from_queue(
        interaction.guild,
        player.id,
        gamemode.strip().lower()
    )

    if removed_mode:
        print(
            f"Queue completed | "
            f"Player: {player} | "
            f"Gamemode: {removed_mode}"
        )

    print(
        f"Result created | "
        f"Username: {username} | "
        f"Tester: {interaction.user} | "
        f"Tier: {previous_tier.value} -> "
        f"{new_tier.value} | "
        f"Face found: {image_found}"
    )



@bot.command(name="delq")
async def delq(ctx):
    if not ctx.guild or not (
        ctx.author.guild_permissions.administrator
        or has_role(ctx.author, "TESTER TEAM")
    ):
        return await ctx.send(
            "❌ You don't have permission to use this command.",
            delete_after=5
        )

    mode = next(
        (
            m for m, (_, ch) in QUEUE_CONFIG.items()
            if ch == ctx.channel.name
        ),
        None
    )

    if not mode:
        return await ctx.send(
            "❌ This is not a queue channel.",
            delete_after=5
        )

    queue = load_queue()

    entries = queue.get(mode, [])

    if not isinstance(entries, list):
        entries = []

    role = discord.utils.get(
        ctx.guild.roles,
        name=QUEUE_CONFIG[mode][0]
    )

    for entry in entries:
        try:
            member = (
                ctx.guild.get_member(int(entry["user_id"]))
                or await ctx.guild.fetch_member(
                    int(entry["user_id"])
                )
            )

            if role and role in member.roles:
                await member.remove_roles(
                    role,
                    reason=f"{mode.title()} queue cleared"
                )

        except Exception:
            pass

    queue[mode] = []
    queue.pop(mode + "_active_tester", None)

    save_queue(queue)

    try:
        await ctx.channel.purge(limit=None)
    except Exception:
        pass

    print(
        f"Queue deleted | Gamemode: {mode} | "
        f"Cleared: {len(entries)} players"
    )

@bot.event
async def on_ready():
    await bot.change_presence(activity=discord.CustomActivity(name="🐐 JustXBlade Tiers"))
    print(
        f"Logged in as {bot.user}"
    )

    guild = discord.Object(
        id=int(GUILD_ID)
    )

    try:
        if PANEL_FILE.exists():
            with open(
                PANEL_FILE,
                "r",
                encoding="utf-8"
            ) as f:
                panel = json.load(f)

            channel = bot.get_channel(
                int(panel["channel_id"])
            )

            if channel is None:
                channel = await bot.fetch_channel(
                    int(panel["channel_id"])
                )

            try:
                old_message = await channel.fetch_message(
                    int(panel["message_id"])
                )
                await old_message.delete()
            except (
                discord.NotFound,
                discord.Forbidden
            ):
                pass

            embed = discord.Embed(
                title="⚔️ Tier Test Registration",
                description=(
                    "Welcome to the tier testing system!\n\n"
                    "Register your Minecraft profile, upload your skin, "
                    "and request a tier test using the buttons below.\n\n"
                    "⚠️ **Minecraft username is case-sensitive.**"
                ),
                color=discord.Color.blurple()
            )

            embed.add_field(
                name="📝 Register / Update",
                value="Register your Minecraft username and region.",
                inline=False
            )

            embed.add_field(
                name="🖼️ Upload / Change Skin",
                value="Upload or replace your Minecraft skin.",
                inline=False
            )

            embed.add_field(
                name="⚡ Request Test",
                value="Request a tier test after registering.",
                inline=False
            )

            new_message = await channel.send(
                embed=embed,
                view=RegisterPanelView()
            )

            with open(
                PANEL_FILE,
                "w",
                encoding="utf-8"
            ) as f:
                json.dump(
                    {
                        "channel_id": channel.id,
                        "message_id": new_message.id
                    },
                    f,
                    indent=2
                )

    except Exception as error:
        print(
            f"Auto /reghere refresh failed: {error}"
        )

    try:
        guild_synced = await bot.tree.sync(guild=guild)
        print(
            f"Synced {len(guild_synced)} command(s) to test server."
        )

    except Exception as error:
        print(
            f"Command sync error: {error}"
        )


bot.run(TOKEN)
